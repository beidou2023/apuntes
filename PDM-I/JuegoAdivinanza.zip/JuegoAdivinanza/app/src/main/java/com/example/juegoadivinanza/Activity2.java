package com.example.juegoadivinanza;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Activity2 extends AppCompatActivity {

    TextView respuesta,aux,inte;
    ViewGroup parent;
    Button buttonRemove;
    int numero,numeroR,intentos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        numero=getIntent().getIntExtra("MiNumero",0);
        numeroR=getIntent().getIntExtra("NumeroAleatorio",0);
        intentos=getIntent().getIntExtra("Intentos",0);

        aux=findViewById(R.id.txv_aux);
        aux.setText(""+numeroR);
        inte=findViewById(R.id.txv_int);
        inte.setText(""+intentos);

        respuesta=findViewById(R.id.txv_respuesta);
        if(numero==numeroR||intentos==7) {
            buttonRemove=findViewById(R.id.btn_repetir);
            parent=(ViewGroup)buttonRemove.getParent();
            parent.removeView(buttonRemove);
            if(numero==numeroR) {
                respuesta.setBackgroundColor(Color.GREEN);
                respuesta.setText("Adivinaste el numero");
            }
            else {
                respuesta.setBackgroundColor(Color.RED);
                respuesta.setText("Usted excedio la cantidad de oportunidades");
            }
        }
        else if(Math.abs(numero-numeroR)<=5){
            respuesta.setBackgroundColor(Color.YELLOW);
            respuesta.setText("El numero ingresado esta muy cerca");
        }
        else if(Math.abs(numeroR-numero)<=10){
            respuesta.setBackgroundColor(Color.BLUE);
            if(numeroR>numero)
                respuesta.setText("El numero ingresado es menor en 10. Intenta de nuevo");
            else
                respuesta.setText("El numero ingresado es mayor en 10. Intenta de nuevo");
        }
        else{
            respuesta.setBackgroundColor(Color.WHITE);
            respuesta.setText("Intenta de nuevo");
        }
    }

    public void IntentarNuevo(View v){
        Intent it=new Intent(getApplicationContext(), MainActivity.class);
        it.putExtra("Intentos",intentos);
        it.putExtra("NumeroAleatorio",numeroR);
        startActivity(it);

    }

}