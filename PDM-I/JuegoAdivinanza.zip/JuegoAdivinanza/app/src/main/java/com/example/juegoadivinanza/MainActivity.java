package com.example.juegoadivinanza;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView aux,inte;
    int intentos=0,numeroR;
    EditText miNumero;
    Random r=new Random();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        intentos=getIntent().getIntExtra("Intentos",0);
        if(intentos==0){
            numeroR= r.nextInt(100)+1;
        }
        else{
            numeroR=getIntent().getIntExtra("NumeroAleatorio",0);
        }
        miNumero=findViewById(R.id.edt_minumero);

        aux=findViewById(R.id.txv_aux);
        aux.setText(""+numeroR);
        inte=findViewById(R.id.txv_int);
        inte.setText(""+intentos);

    }

    public void Intentar(View v){
        int numero=Integer.parseInt(miNumero.getText().toString());
        Intent it=new Intent(getApplicationContext(), Activity2.class);
        it.putExtra("MiNumero",numero);
        it.putExtra("NumeroAleatorio",numeroR);
        intentos++;
        it.putExtra("Intentos",intentos);
        startActivity(it);
    }
}