namespace Examen2
{
    internal class Vehiculo
    {
        public string placa;
        public string marca;
        public double precio;

        public Vehiculo(string placa, string marca, double precio)
        {
            this.placa = placa;
            this.marca = marca;
            this.precio = precio;
        }
        public Vehiculo()
        {

        }
    }
}
